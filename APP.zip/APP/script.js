function saveTask() {
    var summary = document.getElementById('summary').value;
    var startDate = document.getElementById('startDate').value;
    var endDate = document.getElementById('endDate').value;
    var assignedBy = document.getElementById('assignedBy').value;
    var assignedTo = document.getElementById('assignedTo').value;
    var status = document.getElementById('status').value;

    var task = {
        summary: summary,
        startDate: startDate,
        endDate: endDate,
        assignedBy: assignedBy,
        assignedTo: assignedTo,
        status: status
    };

    addTaskToTable(task);
}

function addTaskToTable(task) {
    var table = document.getElementById('taskList');
    var row = table.insertRow();
    row.insertCell(0).textContent = task.summary;
    row.insertCell(1).textContent = task.startDate;
    row.insertCell(2).textContent = task.endDate;
    row.insertCell(3).textContent = task.assignedBy;
    row.insertCell(4).textContent = task.assignedTo;
    row.insertCell(5).textContent = task.status;
    var editCell = row.insertCell(6);
    var editButton = document.createElement('button');
    editButton.textContent = 'Edit';
    editButton.onclick = function() {
        editTask(row);
    };
    editCell.appendChild(editButton);
}

function editTask(row) {
    var cells = row.cells;
    var summary = cells[0].textContent;
    var startDate = cells[1].textContent;
    var endDate = cells[2].textContent;
    var assignedBy = cells[3].textContent;
    var assignedTo = cells[4].textContent;
    var status = cells[5].textContent;

    document.getElementById('summary').value = summary;
    document.getElementById('startDate').value = startDate;
    document.getElementById('endDate').value = endDate;
    document.getElementById('assignedBy').value = assignedBy;
    document.getElementById('assignedTo').value = assignedTo;
    document.getElementById('status').value = status;

    // Remove the row from the table
    row.parentNode.removeChild(row);
}
