function addTask() {
    var employeeNameInput = document.getElementById("employeeName").value;
    var assignedByInput = document.getElementById("assignedBy").value;
    var projectDescriptionInput = document.getElementById("projectDescription").value;
    var assignedDateInput = document.getElementById("assignedDate").value;
    var dueDateInput = document.getElementById("dueDate").value;
    var completionDateInput = document.getElementById("completionDate").value;
    var statusSelect = document.getElementById("status").value;

    if (employeeNameInput.trim() === "" || assignedByInput.trim() === "" || projectDescriptionInput.trim() === "" || assignedDateInput.trim() === "" || dueDateInput.trim() === "") {
        alert("Please fill in all required fields!");
        return;
    }

    var table = document.querySelector("table");
    var row = table.insertRow(-1);

    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    var cell7 = row.insertCell(6);
    var cell8 = row.insertCell(7);
    var cell9 = row.insertCell(8);
    var cell10 = row.insertCell(9);

    cell1.textContent = document.getElementById("prefix").value;
    cell2.textContent = employeeNameInput;
    cell3.textContent = assignedByInput;
    cell4.textContent = projectDescriptionInput;
    cell5.textContent = assignedDateInput;
    cell6.textContent = dueDateInput;
    cell7.textContent = completionDateInput || "Not Completed";
    cell8.textContent = statusSelect.charAt(0).toUpperCase() + statusSelect.slice(1);
    cell9.innerHTML = '<button onclick="deleteTask(this)">Delete</button>';
}

function deleteTask(button) {
    var row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
}
